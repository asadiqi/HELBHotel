package com.example.helbhotel.tiket;

public abstract class Tiket {
}
