package com.example.helbhotel.tiket;

public class Gold {
}
