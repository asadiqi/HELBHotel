package com.example.helbhotel;

public class Factory {
    
}
