package com.example.helbhotel;

public interface Strategy {

}
