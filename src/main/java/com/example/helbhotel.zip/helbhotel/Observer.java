package com.example.helbhotel;

public interface Observer {
}
